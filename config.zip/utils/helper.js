import crypto from 'crypto';
import { fileURLToPath } from 'url';
import path from 'path';
import nodemailer from 'nodemailer';
import base64url from 'base64url'
import hbs from 'nodemailer-express-handlebars';
import { PrismaClient } from '@prisma/client';
const baseurl = process.env.BASE_URL;
import Joi from 'joi';
import { emitSocketEvent } from '../utils/socket.js'; // Assuming you have this utility function
import { ChatEventEnum } from '../utils/constants.js';
import { createNotificationForAuthor, sendNotificationRelateToMessageToAuthor, sendNotificationRelateToMessageToUser, createNotificationForUser } from "../utils/notification.js";

import dotenv from "dotenv";
dotenv.config();
import { createErrorResponse, createSuccessResponse } from '../utils/responseUtil.js';
import { MessageEnum } from '../config/message.js';

const prisma = new PrismaClient();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

var transporter = nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 587,
    auth: {
        user: "kpatel74155@gmail.com",
        pass: "mitbpoatzprnwfac",
    },
});

const handlebarOptions = {
    viewEngine: {
        partialsDir: path.resolve(__dirname, "../view/"),
        defaultLayout: false,
    },
    viewPath: path.resolve(__dirname, "../view/"),
};

transporter.use("compile", hbs(handlebarOptions));


export async function generateOTP(length = 4) {
    const chars = "0123456789";
    let OTP = "";

    for (let i = 0; i < length; i++) {
        const randomIndex = crypto.randomInt(0, chars.length);
        OTP += chars.charAt(randomIndex);
    }

    return OTP;
}


export async function getFollowedAuthors(userId) {
    try {
        const followedAuthors = await prisma.follow.count({
            where: { followerId: userId }, // Assuming status 1 means "following"
            select: {
                following: { // Fetch author details
                    select: {
                        id: true,
                        name: true, // Assuming `name` exists in the Author model
                        bio: true,  // Assuming `bio` exists in the Author model
                        profilePicture: true, // Assuming `profilePicture` exists in the Author model
                    },
                },
            },
        });

        return followedAuthors.map(follow => follow.following);
    } catch (error) {
        console.error("Error fetching followed authors:", error);
        throw new Error("Could not retrieve followed authors");
    }
}

export function randomStringAsBase64Url(size) {
    return base64url(crypto.randomBytes(size));
}

export async function getAuthorStats(authorId) {
    // Count the number of books published by the author
    const publishedCount = await prisma.book.count({
        where: { authorId }
    });

    // Count the number of followers for the author
    const followersCount = await prisma.follow.count({
        where: { followingId: authorId }
    });

    return { publishedCount, followersCount };
}




// export async function sendMessagesByAuthor(req, res) {
//     try {
//         console.log('req.params', req.params);
//         console.log('req.body', req.body);

//         const { chatId } = req.params;
//         const { content, isLink, fileName } = req.body;

//         const chat = await prisma.chat.findUnique({
//             where: { id: parseInt(chatId) },
//             include: { participants: true }
//         });
//         console.log('chat', chat);

//         const message = await prisma.chatMessage.create({
//             data: {
//                 content: content || '',
//                 senderAuthorId: req.user.id,
//                 chatId: parseInt(chatId),
//                 isLink: isLink ? parseInt(isLink) : 0,
//                 fileName: fileName || null
//             }
//         });
//         console.log('message', message);

//         const updateChat = await prisma.chat.update({
//             where: { id: parseInt(chatId) },
//             data: { lastMessageId: message.id },
//             include: { participants: true }
//         });

//         const socketMessage = await prisma.chatMessage.findUnique({
//             where: { id: message.id },
//             include: { senderAuthor: true, chat: true }
//         });
//         console.log("updateChat", updateChat);

//         await Promise.all(updateChat.participants.map(async (participant) => {
//             if (participant.authorId === req.user.id) return;
//             const recipientId = participant.userId || participant.authorId;
//             const roomName = participant.userId ? `user_${participant.userId}` : `author_${participant.authorId}`;

//             emitSocketEvent(req, roomName, ChatEventEnum.MESSAGE_RECEIVED_EVENT, socketMessage);

//             const recipient = await prisma.user.findUnique({
//                 where: { id: recipientId },
//                 select: { fcm_token: true }
//             });

//             await sendMessageNotification({
//                 token: recipient.fcm_token,
//                 senderId: req.user.id,
//                 receiverId: recipientId,
//                 senderName: req.user.fullName,
//                 isAuthor: true
//             });

//             await prisma.userNotification.create({
//                 data: {
//                     senderId: req.user.id,
//                     receiverId: recipientId,
//                     messageId: message.id,
//                     createdAt: new Date(),
//                     isRead: false
//                 }
//             });
//         }));

//         return res.status(200).json({
//             status: 200,
//             message: 'Message sent successfully',
//             success: true,
//             message: socketMessage
//         });
//     } catch (error) {
//         console.error(error);
//         return res.status(500).json({
//             status: 500,
//             message: 'Internal Server Error',
//             success: false,
//             error: error.message
//         });
//     }
// }


export async function sendMessagesByAuthor(req, res) {
    try {
        console.log('req.params', req.params)
        console.log('req.body', req.body)
        const { chatId } = req.params;
        const { content, isLink, fileNames } = req.body;
        console.log("??????????????????????", req.user)
        const uploadedFiles = fileNames ? fileNames.split(",") : [];
        // const uploadedFiles = fileNames || [];

        const chat = await prisma.chat.findUnique({
            where: {
                id: parseInt(chatId)
            },
            include: {
                participants: true
            }
        })
        console.log('chat', chat)
        const message = await prisma.chatMessage.create({
            data: {
                content: content || '',
                senderAuthorId: req.user.id,
                chatId: parseInt(chatId),
                isLink: isLink ? parseInt(isLink) : 0,
                // fileNames: uploadedFiles.length > 0 ? uploadedFiles.join(",") : null,
                // fileName: fileName || null
            }
        });
        console.log('message', message)

        if (uploadedFiles.length > 0) {
            await prisma.chatMessageFiles.createMany({
                data: uploadedFiles.map(file => ({
                    messageId: message.id,
                    fileName: file
                }))
            });
        }
        const updateChat = await prisma.chat.update({
            where: {
                id: parseInt(chatId)
            },
            data: {
                lastMessageId: message.id
            }, include: {
                participants: true
            }
        })
        const socketMessage = await prisma.chatMessage.findUnique({
            where: {
                id: message.id
            },
            include: {
                senderAuthor: true,
                chat: true,
            }
        })
        console.log("updateChat", updateChat)

        const author = await prisma.author.findUnique({
            where: {
                id: req.user.id
            }
        })

        await Promise.all(updateChat.participants.map(async (participant) => {
            if (participant.authorId === req.user.id) return;

            if (participant.authorId) {
                console.log("for author");
                const roomName = `author_${participant.authorId}`
                emitSocketEvent(
                    req,
                    roomName,
                    ChatEventEnum.MESSAGE_RECEIVED_EVENT,
                    socketMessage
                );
                const unreadCount = await prisma.authorUnreadCount.findFirst({
                    where: {
                        authorId: participant.authorId,
                        chatId: parseInt(chatId)
                    }
                });

                console.log('unreadCount', unreadCount)

                if (unreadCount) {
                    // If UnreadCount exists, update the unreadCount by 1
                    await prisma.authorUnreadCount.update({
                        where: {
                            id: unreadCount.id
                        },
                        data: {
                            unreadCount: unreadCount.unreadCount + 1
                        }
                    });
                } else {
                    // If UnreadCount does not exist, create a new one
                    await prisma.authorUnreadCount.create({
                        data: {
                            authorId: participant.authorId,
                            chatId: parseInt(chatId),
                            unreadCount: 1
                        }
                    });
                }
            }

            if (participant.userId) {
                console.log("for user")
                const roomName = `user_${participant.userId}`
                emitSocketEvent(
                    req,
                    roomName,
                    ChatEventEnum.MESSAGE_RECEIVED_EVENT,
                    socketMessage
                );
                await sendNotificationRelateToMessageToUser({
                    token: author.fcm_token,
                    body: `${req.user.full_name} sent you a message`,
                });


                // ✅ Create notification inside the loop where `participant` is defined
                await createNotificationForUser({
                    toUserId: participant.userId,
                    byAuthorId: req.user.id,
                    data: {
                        userId: req.user.id
                    },
                    type: "chat",
                    content: `${req.user.fullName} sent you a message`
                });

                const unreadCount = await prisma.userUnreadCount.findFirst({
                    where: {
                        userId: participant.userId,
                        chatId: parseInt(chatId)
                    }
                });

                if (unreadCount) {
                    // If UnreadCount exists, update the unreadCount by 1
                    await prisma.userUnreadCount.update({
                        where: {
                            id: unreadCount.id
                        },
                        data: {
                            unreadCount: unreadCount.unreadCount + 1
                        }
                    });
                } else {
                    // If UnreadCount does not exist, create a new one
                    await prisma.userUnreadCount.create({
                        data: {
                            userId: participant.userId,
                            chatId: parseInt(chatId),
                            unreadCount: 1
                        }
                    });
                }
            }
        }));

        // Send push notification outside the loop (no need for `participant` here)


    } catch (error) {
        console.log(error);

    }
}

// export async function sendMessagesByAuthor(req, res) {
//     try {
//         const { chatId } = req.params;
//         const { content, isLink, fileNames } = req.body;
//         const uploadedFiles = fileNames ? fileNames.split(",") : [];
//         const parsedChatId = parseInt(chatId);

//         const chat = await prisma.chat.findUnique({
//             where: { id: parsedChatId },
//             include: { participants: true }
//         });

//         if (!chat) {
//             return res.status(404).json({ error: "Chat not found" });
//         }

//         const message = await prisma.chatMessage.create({
//             data: {
//                 content: content || '',
//                 senderAuthorId: req.user.id,
//                 chatId: parsedChatId,
//                 isLink: isLink ? parseInt(isLink) : 0
//             }
//         });

//         if (uploadedFiles.length > 0) {
//             await prisma.chatMessageFiles.createMany({
//                 data: uploadedFiles.map(file => ({
//                     messageId: message.id,
//                     fileName: file
//                 }))
//             });
//         }

//         const updateChat = await prisma.chat.update({
//             where: { id: parsedChatId },
//             data: { lastMessageId: message.id },
//             include: { participants: true }
//         });

//         const socketMessage = await prisma.chatMessage.findUnique({
//             where: { id: message.id },
//             include: {
//                 senderAuthor: true,
//                 chat: true,
//             }
//         });

//         const author = await prisma.author.findUnique({
//             where: { id: req.user.id }
//         });

//         await Promise.all(updateChat.participants.map(async (participant) => {
//             if (participant.authorId === req.user.id) return;

//             if (participant.authorId) {
//                 const roomName = `author_${participant.authorId}`;
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//             }

//             const existingUnread = await prisma.authorUnreadCount.findFirst({
//                 where: {
//                     authorId: participant.authorId,
//                     chatId: parsedChatId
//                 }
//             });

//             if (existingUnread) {
//                 await prisma.authorUnreadCount.update({
//                     where: { id: existingUnread.id },
//                     data: { unreadCount: existingUnread.unreadCount + 1 }
//                 });
//             } else {
//                 await prisma.authorUnreadCount.create({
//                     data: {
//                         authorId: participant.authorId,
//                         chatId: parsedChatId,
//                         unreadCount: 1
//                     }
//                 });
//             }

//             if (participant.userId) {
//                 const roomName = `user_${participant.userId}`;
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//             }

//             await createNotificationForUser({
//                 toUserId: participant.userId,
//                 byAuthorId: req.user.id,
//                 data: { userId: req.user.id },
//                 type: "chat",
//                 content: `${req.user.fullName} sent you a message`
//             });
//         }));

//         await sendNotificationRelateToMessageToUser({
//             token: author.fcm_token,
//             body: `${req.user.fullName} sent you a message`,
//         });

//     } catch (error) {
//         console.error("Error in sendMessagesByAuthor:", error);

//     }
// }




// export async function sendMessagesByUser(req, res) {
//     try {
//         console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>here')
//         console.log('req.params', req.params)
//         console.log('req.body', req.body)
//         const { chatId } = req.params;
//         const { content, isLink, fileName } = req.body;
//         // const userId = req.user.id;
//         const chat = await prisma.chat.findUnique({
//             where: {
//                 id: parseInt(chatId)
//             },
//             include: {
//                 participants: true
//             }
//         })
//         console.log('chat', chat)
//         const message = await prisma.chatMessage.create({
//             data: {
//                 content: content || '',
//                 senderUserId: req.user.id,
//                 chatId: parseInt(chatId),
//                 isLink: isLink ? parseInt(isLink) : 0,
//                 fileName: fileName || null
//             }
//         });
//         console.log('message', message)
//         const updateChat = await prisma.chat.update({
//             where: {
//                 id: parseInt(chatId)
//             },
//             data: {
//                 lastMessageId: message.id
//             }, include: {
//                 participants: true
//             }
//         })
//         const socketMessage = await prisma.chatMessage.findUnique({
//             where: {
//                 id: message.id
//             },
//             include: {
//                 senderUser: true,
//                 chat: true,
//             }
//         })

//         const user = await prisma.user.findUnique({
//             where: {
//                 id: req.user.id
//             }
//         })

//         console.log('user', user)

//         socketMessage.fileName = socketMessage.fileName ? baseurl + "/books/" + socketMessage.fileName : null

//         console.log("updateChat", updateChat)

//         await Promise.all(updateChat.participants.map(async (participant) => {
//             if (participant.userId === req.user.id) return;

//             if (participant.authorId) {
//                 console.log("for author");
//                 const roomName = `author_${participant.authorId}`
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//                 await createNotificationForUser({
//                     toAuthorId: participant.authorId,
//                     byUserId: req.user.id,
//                     data: {
//                         userId: req.user.id
//                     },
//                     type: "chat",
//                     content: `${req.user.full_name} send you a message`
//                 })
//                 await sendNotificationRelateToMessageToAuthor({
//                     token: user.fcm_token,
//                     body: `${req.user.full_name} send you a message`,
//                 })

//             }
//             if (participant.userId) {
//                 console.log("for user")
//                 const roomName = `user_${participant.userId}`
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//             }

//         }))

//     } catch (error) {
//         console.log(error);

//     }
// }


// export async function sendMessagesByUser(req, res) {
//     try {
//         console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>here')
//         console.log('req.params', req.params)
//         console.log('req.body', req.body)
//         const { chatId } = req.params;
//         const { content, isLink, fileNames } = req.body;
//         const uploadedFiles = fileNames ? fileNames.split(",") : [];
//         // const uploadedFiles = fileNames || [];

//         // const userId = req.user.id;
//         const chat = await prisma.chat.findUnique({
//             where: {
//                 id: parseInt(chatId)
//             },
//             include: {
//                 participants: true
//             }
//         })
//         console.log('chat', chat)
//         const message = await prisma.chatMessage.create({
//             data: {
//                 content: content || '',
//                 senderUserId: req.user.id,
//                 chatId: parseInt(chatId),
//                 isLink: isLink ? parseInt(isLink) : 0,
//                 // fileNames: uploadedFiles.length > 0 ? uploadedFiles.join(",") : null, // Convert array to comma-separated string
//                 // fileName: fileName || null
//             }
//         });
//         console.log('message', message)
//         if (uploadedFiles.length > 0) {
//             await prisma.chatMessageFiles.createMany({
//                 data: uploadedFiles.map(file => ({
//                     messageId: message.id,
//                     fileName: file
//                 }))
//             });
//         }
//         const updateChat = await prisma.chat.update({
//             where: {
//                 id: parseInt(chatId)
//             },
//             data: {
//                 lastMessageId: message.id
//             }, include: {
//                 participants: true
//             }
//         })
//         const socketMessage = await prisma.chatMessage.findUnique({
//             where: {
//                 id: message.id
//             },
//             include: {
//                 senderUser: true,
//                 chat: true,
//             }
//         })

//         const user = await prisma.user.findUnique({
//             where: {
//                 id: req.user.id
//             }
//         })

//         console.log('user', user)

//         socketMessage.fileName = socketMessage.fileName ? baseurl + "/books/" + socketMessage.fileName : null

//         console.log("updateChat", updateChat)

//         // ✅ Handle unread count + socket notifications
//         await Promise.all(updateChat.participants.map(async (participant) => {
//             if (participant.userId === req.user.id) return; // Skip sender

//             console.log('participant.userId', participant.userId)

//             console.log('req.user.id', req.user.id)

//             if (participant.authorId) {
//                 console.log("for author");
//                 const roomName = `author_${participant.authorId}`
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//                 await createNotificationForAuthor({
//                     toAuthorId: participant.authorId,
//                     byUserId: req.user.id,
//                     data: {
//                         userId: req.user.id
//                     },
//                     type: "chat",
//                     content: `${req.user.fullName} send you a message`
//                 })
//                 await sendNotificationRelateToMessageToAuthor({
//                     token: user.fcm_token,
//                     body: `${req.user.fullName} send you a message`,
//                 })

//             }
//             if (participant.userId) {
//                 console.log("for user")
//                 const roomName = `user_${participant.userId}`
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//             }
//         }))
//     } catch (error) {
//         console.log(error);

//     }
// }

export async function sendMessagesByUser(req, res) {
    try {
        console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>here')
        console.log('req.params', req.params)
        console.log('req.body', req.body)
        const { chatId } = req.params;
        const { content, isLink, fileNames } = req.body;
        const uploadedFiles = fileNames ? fileNames.split(",") : [];
        // const uploadedFiles = fileNames || [];

        // const userId = req.user.id;
        const chat = await prisma.chat.findUnique({
            where: {
                id: parseInt(chatId)
            },
            include: {
                participants: true
            }
        })
        console.log('chat', chat)
        const message = await prisma.chatMessage.create({
            data: {
                content: content || '',
                senderUserId: req.user.id,
                chatId: parseInt(chatId),
                isLink: isLink ? parseInt(isLink) : 0,
                // fileNames: uploadedFiles.length > 0 ? uploadedFiles.join(",") : null, // Convert array to comma-separated string
                // fileName: fileName || null
            }
        });
        console.log('message', message)
        if (uploadedFiles.length > 0) {
            await prisma.chatMessageFiles.createMany({
                data: uploadedFiles.map(file => ({
                    messageId: message.id,
                    fileName: file
                }))
            });
        }
        const updateChat = await prisma.chat.update({
            where: {
                id: parseInt(chatId)
            },
            data: {
                lastMessageId: message.id
            }, include: {
                participants: true
            }
        })
        const socketMessage = await prisma.chatMessage.findUnique({
            where: {
                id: message.id
            },
            include: {
                senderUser: true,
                chat: true,
            }
        })

        const user = await prisma.user.findUnique({
            where: {
                id: req.user.id
            }
        })

        console.log('user', user)

        socketMessage.fileName = socketMessage.fileName ? baseurl + "/books/" + socketMessage.fileName : null

        console.log("updateChat", updateChat)

        // ✅ Handle unread count + socket notifications
        await Promise.all(updateChat.participants.map(async (participant) => {
            if (participant.userId === req.user.id) return; // Skip sender

            console.log('participant.userId', participant.userId)

            console.log('req.user.id', req.user.id)

            if (participant.authorId) {
                console.log("for author");
                const roomName = `author_${participant.authorId}`
                emitSocketEvent(
                    req,
                    roomName,
                    ChatEventEnum.MESSAGE_RECEIVED_EVENT,
                    socketMessage
                );
                await createNotificationForAuthor({
                    toAuthorId: participant.authorId,
                    byUserId: req.user.id,
                    data: {
                        userId: req.user.id
                    },
                    type: "chat",
                    content: `${req.user.fullName} send you a message`
                })
                await sendNotificationRelateToMessageToAuthor({
                    token: user.fcm_token,
                    body: `${req.user.fullName} send you a message`,
                })

                const unreadCount = await prisma.authorUnreadCount.findFirst({
                    where: {
                        authorId: participant.authorId,
                        chatId: parseInt(chatId)
                    }
                });

                console.log('unreadCount', unreadCount)

                if (unreadCount) {
                    // If UnreadCount exists, update the unreadCount by 1
                    await prisma.authorUnreadCount.update({
                        where: {
                            id: unreadCount.id
                        },
                        data: {
                            unreadCount: unreadCount.unreadCount + 1
                        }
                    });
                } else {
                    // If UnreadCount does not exist, create a new one
                    await prisma.authorUnreadCount.create({
                        data: {
                            authorId: participant.authorId,
                            chatId: parseInt(chatId),
                            unreadCount: 1
                        }
                    });
                }

            }
            if (participant.userId) {
                console.log("for user")
                const roomName = `user_${participant.userId}`
                emitSocketEvent(
                    req,
                    roomName,
                    ChatEventEnum.MESSAGE_RECEIVED_EVENT,
                    socketMessage
                );
                const unreadCount = await prisma.userUnreadCount.findFirst({
                    where: {
                        userId: participant.userId,
                        chatId: parseInt(chatId)
                    }
                });

                console.log('unreadCount', unreadCount)

                if (unreadCount) {
                    // If UnreadCount exists, update the unreadCount by 1
                    await prisma.userUnreadCount.update({
                        where: {
                            id: unreadCount.id
                        },
                        data: {
                            unreadCount: unreadCount.unreadCount + 1
                        }
                    });
                } else {
                    // If UnreadCount does not exist, create a new one
                    await prisma.userUnreadCount.create({
                        data: {
                            userId: participant.userId,
                            chatId: parseInt(chatId),
                            unreadCount: 1
                        }
                    });
                }
            }

        }))
    } catch (error) {
        console.log(error);

    }
}


// export async function sendMessagesByUser(req, res) {
//     try {
//         console.log('>>>>>>>>>>>>>>>>>>>>>>>>>>>>>here');
//         console.log('req.params', req.params);
//         console.log('req.body', req.body);

//         const { chatId } = req.params;
//         const { content, isLink, fileNames } = req.body;
//         const uploadedFiles = fileNames ? fileNames.split(",") : [];

//         const chat = await prisma.chat.findUnique({
//             where: { id: parseInt(chatId) },
//             include: { participants: true }
//         });

//         if (!chat) {
//             return res.status(404).json({ message: "Chat not found" });
//         }

//         const message = await prisma.chatMessage.create({
//             data: {
//                 content: content || '',
//                 senderUserId: req.user.id,
//                 chatId: parseInt(chatId),
//                 isLink: isLink ? parseInt(isLink) : 0,
//             }
//         });

//         if (uploadedFiles.length > 0) {
//             await prisma.chatMessageFiles.createMany({
//                 data: uploadedFiles.map(file => ({
//                     messageId: message.id,
//                     fileName: file
//                 }))
//             });
//         }

//         const updateChat = await prisma.chat.update({
//             where: { id: parseInt(chatId) },
//             data: { lastMessageId: message.id },
//             include: { participants: true }
//         });

//         const socketMessage = await prisma.chatMessage.findUnique({
//             where: { id: message.id },
//             include: {
//                 senderUser: true,
//                 chat: true
//             }
//         });

//         const user = await prisma.user.findUnique({
//             where: { id: req.user.id }
//         });

//         if (socketMessage && socketMessage.fileName) {
//             socketMessage.fileName = baseurl + "/books/" + socketMessage.fileName;
//         }

//         console.log("updateChat", updateChat);

//         for (const participant of updateChat.participants) {
//             // Skip sender for both userId and authorId
//             if (participant.userId === req.user.id || participant.authorId === req.user.id) {
//                 continue;
//             }

//             // 🔄 Handle unread count and socket event for users
//             if (participant.userId) {
//                 const existingCount = await prisma.userUnreadCount.findFirst({
//                     where: {
//                         chatId: parseInt(chatId),
//                         userId: participant.userId
//                     }
//                 });

//                 if (existingCount) {
//                     await prisma.userUnreadCount.update({
//                         where: { id: existingCount.id },
//                         data: {
//                             unreadCount: { increment: 1 }
//                         }
//                     });
//                 } else {
//                     await prisma.userUnreadCount.create({
//                         data: {
//                             chatId: parseInt(chatId),
//                             userId: participant.userId,
//                             unreadCount: 1
//                         }
//                     });
//                 }

//                 console.log("for user");
//                 const roomName = `user_${participant.userId}`;
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );
//             }

//             // 🔔 Handle author socket and notification
//             if (participant.authorId) {
//                 console.log("for author");
//                 const roomName = `author_${participant.authorId}`;
//                 emitSocketEvent(
//                     req,
//                     roomName,
//                     ChatEventEnum.MESSAGE_RECEIVED_EVENT,
//                     socketMessage
//                 );

//                 await createNotificationForAuthor({
//                     toAuthorId: participant.authorId,
//                     byUserId: req.user.id,
//                     data: {
//                         userId: req.user.id
//                     },
//                     type: "chat",
//                     content: `${req.user.fullName} sent you a message`
//                 });

//                 await sendNotificationRelateToMessageToAuthor({
//                     token: user?.fcm_token,
//                     body: `${req.user.fullName} sent you a message`
//                 });
//             }
//         }

//     } catch (error) {
//         console.log(error);

//     }
// }