import express from 'express';
import {
    login,
    forgotPassword,
    verifyForgetPasswordOtp,
    resetPassword,
    getdashboard,
    getAllReader,
    toggleUserStatusByAdmin,
    getAllAuthor,
    getAllEbook,
    toggleAuthorStatusByAdmin,
    getAllChats
} from '../controllers/adminController.js';;
import { adminAuth } from "../middlewares/adminAuth.js";

export const adminRoutes = express.Router();

adminRoutes.post('/login', login);

adminRoutes.post('/forgotPassword',  forgotPassword);

adminRoutes.post('/verifyForgetPasswordOtp', verifyForgetPasswordOtp);

adminRoutes.post('/resetPassword', resetPassword);

adminRoutes.get('/getdashboard', adminAuth, getdashboard);

adminRoutes.get('/getAllReader', adminAuth, getAllReader);

adminRoutes.get('/getAllAuthor', adminAuth, getAllAuthor);

adminRoutes.get('/toggleUserStatusByAdmin/:id', adminAuth, toggleUserStatusByAdmin);

adminRoutes.get('/toggleAuthorStatusByAdmin/:id', adminAuth, toggleAuthorStatusByAdmin);

adminRoutes.get('/getAllAuthor', adminAuth, getAllAuthor);

adminRoutes.get('/getAllEbook', adminAuth, getAllEbook);

adminRoutes.get('/getAllChats',adminAuth, getAllChats);