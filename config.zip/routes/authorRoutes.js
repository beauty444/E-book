import express from 'express';
import {
    signupWithEmail,
    verifyUserEmail,
    login,
    deleteImage,
    forgotPassword,
    verifyForgetPasswordOtp,
    resetPassword,
    editProfile,
    createBook,
    editBook,
    socialLogin,
    myProfile,
    changePassword,
    deleteBook,
    getAllBook,
    getBookById,
    addToCart,
    getdashboard,
    createGroupChat,
    getAllCategories,
    addMemberInTeam,
    removeMemberFromTeam,
    getAllChats,
    activateDeactivateChat,
    createOrGetAOneOnOneChat,
    createOrGetAOneOnOneChatInUser,
    getAllMessages,
    clearChat,
    fileUploadforImage,
    getAllAuthorNotification,
    deleteAllNotification,
    deleteNotification

} from '../controllers/authorController.js';
import { upload } from "../middlewares/upload.js";
import { authorAuth } from "../middlewares/authorAuth.js";

export const authorRouter = express.Router();

authorRouter.post('/signupByEmail', signupWithEmail);

authorRouter.get('/verifyUser/:id', verifyUserEmail);

authorRouter.post('/login', login);

authorRouter.post('/social-login', socialLogin);

authorRouter.post('/forgetPassword', forgotPassword);

authorRouter.post('/verifyForgetPasswordOtp', verifyForgetPasswordOtp);

authorRouter.post('/resetPassword', resetPassword);

authorRouter.post('/changePassword',authorAuth, changePassword);

authorRouter.get('/myProfile',authorAuth, myProfile);

authorRouter.post('/addToCart', authorAuth,  addToCart);

authorRouter.get('/getAllCategories', authorAuth, getAllCategories);

authorRouter.get('/getAllBook', authorAuth, getAllBook);

authorRouter.get('/getAllBook/:id', authorAuth, getBookById);

authorRouter.put('/editProfile', authorAuth, upload.fields([
    { name: "coverImage", maxCount: 1 },
    { name: "avatar_url", maxCount: 1 },
]), editProfile);

authorRouter.post(
    "/create",
    authorAuth,
    upload.fields([
        { name: "coverImage", maxCount: 1 },
        { name: "pdfUrl", maxCount: 1 },
        { name: "audioUrl", maxCount: 1 },
        { name: "bookMedia", maxCount: 10 },
    ]),
    createBook
);

authorRouter.put(
    '/editBook',
    authorAuth,
    upload.fields([
      { name: 'coverImage', maxCount: 1 },
      { name: 'pdfUrl', maxCount: 1 },
      { name: 'audioUrl', maxCount: 1 },
      { name: 'bookMedia', maxCount: 10 },
    ]),
    editBook
  );

authorRouter.delete('/deleteBook/:id', authorAuth, deleteBook);

authorRouter.delete('/deleteImages/:id', authorAuth,  deleteImage);

authorRouter.get('/getdashboard', authorAuth, getdashboard);

authorRouter.get('/getAllAuthorNotification', authorAuth, getAllAuthorNotification);

authorRouter.delete('/deleteAll',authorAuth, deleteAllNotification);

authorRouter.delete('/delete/:notificationId', authorAuth, deleteNotification);

//chat 

authorRouter.post('/createGroupChat', authorAuth, createGroupChat);

authorRouter.post('/members', authorAuth, addMemberInTeam);
 
authorRouter.delete('/members', authorAuth, removeMemberFromTeam);

authorRouter.get('/getAllChats',authorAuth, getAllChats);

authorRouter.post('/chatStatus', authorAuth,  activateDeactivateChat);

authorRouter.post('/chatOnetoOne/:receiverId', authorAuth, createOrGetAOneOnOneChat);

authorRouter.post('/members/:receiverId',  createOrGetAOneOnOneChatInUser);

// message 

authorRouter.get('/getAllMessages/:chatId', authorAuth, getAllMessages);

authorRouter.delete('/:chatId', authorAuth, clearChat);

authorRouter.post('/uploadImages', authorAuth, upload.array("files", 10), fileUploadforImage);

