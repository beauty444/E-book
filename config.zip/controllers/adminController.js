import Joi from "joi";
import jwt from 'jsonwebtoken'
import { PrismaClient } from "@prisma/client";
import bcrypt from 'bcrypt';
import path from 'path'
import crypto from 'crypto';
import dotenv from "dotenv";
import nodemailer from 'nodemailer';
import { randomStringAsBase64Url } from "../utils/helper.js";
import { fileURLToPath } from 'url';
const baseurl = process.env.BASE_URL;
import hbs from "nodemailer-express-handlebars";
import { generateOTP } from "../utils/helper.js"
import { emitSocketEvent } from '../utils/socket.js'; // Assuming you have this utility function
import { ChatEventEnum } from '../utils/constants.js';
import { createErrorResponse, createSuccessResponse } from '../utils/responseUtil.js';
import { MessageEnum } from '../config/message.js';


dotenv.config();
const prisma = new PrismaClient();
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
// const SINCH_APPLICATION_KEY = process.env.SINCH_APPLICATION_KEY
// const SINCH_APPLICATION_SECRET = process.env.SINCH_APPLICATION_SECRET
// const SINCH_BASE_URL = process.env.SINCH_BASE_URL;
// const stripe = new Stripe("sk_test_51OeW3SHceWMrFMej2tClJcj3YuzXnaNj25tZlJW9NMivft8m2YtOlwyzr1VetCPVJjnqpFhjouVnTFxDvlyOGNDl00fFmoFxKB");

var transporter = nodemailer.createTransport({
    // service: 'gmail',
    host: "smtp.gmail.com",
    port: 587,
    // secure: true,
    auth: {
        user: "yashraj.ctinfotech@gmail.com",
        pass: "lggh qqgx fkuc efwq",
    },
});

const handlebarOptions = {
    viewEngine: {
        partialsDir: path.resolve(__dirname, "../view/"),
        defaultLayout: false,
    },
    viewPath: path.resolve(__dirname, "../view/"),
};

transporter.use("compile", hbs(handlebarOptions));

export async function login(req, res) {
    try {
        const secretKey = process.env.SECRET_KEY;
        const { email, password, fcm_token } = req.body;
        const schema = Joi.alternatives(
            Joi.object({
                //email: Joi.string().min(5).max(255).email({ tlds: { allow: false } }).lowercase().required(),
                email: Joi.string()
                    .min(5)
                    .max(255)
                    .email({ tlds: { allow: false } })
                    .lowercase()
                    .required(),
                password: Joi.string().min(8).max(15).required().messages({
                    "any.required": "{{#label}} is required!!",
                    "string.empty": "can't be empty!!",
                    "string.min": "minimum 8 value required",
                    "string.max": "maximum 15 values allowed",
                }),
                fcm_token: Joi.string().optional(),
            })
        );
        const result = schema.validate({ email, password, fcm_token });

        if (result.error) {
            const message = result.error.details.map((i) => i.message).join(",");
            return res.json({
                message: result.error.details[0].message,
                error: message,
                missingParams: result.error.details[0].message,
                status: 400,
                success: false,
            });
        } else {
            const user = await prisma.admin.findUnique({
                where: {
                    email: email,
                },
            });
            if (!user || !(await bcrypt.compare(password, user.password))) {
                return res.status(400).json({
                    success: false,
                    message: "Invalid credentials",
                    status: 400,
                });
            }
            if (fcm_token) {
                await prisma.admin.update({
                    where: {
                        email: email,
                    },
                    data: {
                        fcm_token: fcm_token,
                    },
                });
            }

            const userData = await prisma.admin.findUnique({
                where: {
                    email: email,
                },
            });

            const token = jwt.sign(
                { adminId: user.id, email: user.email },
                secretKey,
                { expiresIn: "3d" }
            );
            return res.json({
                status: 200,
                success: true,
                message: "Login successful!",
                token: token,
                admin: userData,
            });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            status: 500,
            message: "Internal Server Error",
            success: false,
            error: error,
        });
    }
}

export async function forgotPassword(req, res) {
    const { email } = req.body;

    try {
        if (email) {
            const schema = Joi.object({
                email: Joi.string().min(5).max(255).email({ tlds: { allow: false } }).lowercase().required(),
            });

            const result = schema.validate({ email });
            if (result.error) {
                const message = result.error.details.map((i) => i.message).join(",");
                return res.status(400).json({
                    message: result.error.details[0].message,
                    error: message,
                    missingParams: result.error.details[0].message,
                    status: 400,
                    success: false,
                });
            }

            const user = await prisma.user.findUnique({
                where: { email }
            });

            if (!user) {
                return res.status(400).json({
                    success: false,
                    status: 400,
                    message: 'Email not registered'
                });
            }

            const otp = await generateOTP(4);
            console.log('otp', otp);
            const otpExpiration = new Date(Date.now() + 1 * 60000);

            let mailOptions = {
                from: "dataCollector.0901@gmail.com",
                to: email,
                subject: 'Password Reset Request',
                template: 'forgetPassword',
                context: {
                    otp: otp,
                    imgUrl: `${baseurl}/mainLogo.png`
                }
            };

            transporter.sendMail(mailOptions, async function (error, info) {
                if (error) {
                    console.log(error);
                    return res.status(400).json({
                        success: false,
                        status: 400,
                        message: 'Mail Not Delivered'
                    });
                } else {
                    await prisma.user.update({
                        where: { email },
                        data: {
                            otp: otp,
                            otpExpiration: otpExpiration
                        }
                    });
                    return res.status(200).json({
                        success: true,
                        message: "OTP sent to your email. Please check your inbox.",
                        status: 200,
                    });
                }
            });
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            status: 500,
            message: 'Internal Server Error',
            success: false,
            error: error
        });
    }
}

export async function verifyForgetPasswordOtp(req, res) {
    const { email, otp, phone_no } = req.body;

    try {
        if (email && otp) {
            const schema = Joi.alternatives(Joi.object({
                email: Joi.string().min(5).max(255).email({ tlds: { allow: false } }).lowercase().required(),
                otp: Joi.string().required()
            }))
            const result = schema.validate(req.body);
            if (result.error) {
                const message = result.error.details.map((i) => i.message).join(",");
                return res.status(400).json({
                    message: result.error.details[0].message,
                    error: message,
                    missingParams: result.error.details[0].message,
                    status: 400,
                    success: false,
                });
            }
            const user = await prisma.user.findUnique({
                where: { email }
            });

            if (user && user.otp === otp && new Date(user.otpExpiration) > new Date()) {
                await prisma.user.update({
                    where: { email },
                    data: { otp: null, otpExpiration: null }
                });
                return res.status(200).json({
                    message: 'Otp Verified Successfully',
                    status: 200,
                    success: true,
                });
            } else {
                return res.status(400).json({
                    message: 'Invalid or expired OTP',
                    status: 400,
                    success: true
                });
            }
        }
        if (phone_no && otp) {
            console.log(req.body);
            console.log("after");

            const phoneSchema = Joi.object({
                phone_no: Joi.string().min(10).max(15).required(),
                otp: Joi.string().required()
            });

            const phoneResult = phoneSchema.validate({ phone_no, otp });
            if (phoneResult.error) {
                const message = phoneResult.error.details.map((i) => i.message).join(",");
                return res.status(400).json({
                    message: phoneResult.error.details[0].message,
                    error: message,
                    missingParams: phoneResult.error.details[0].message,
                    status: 400,
                    success: false,
                });
            }


            const user = await prisma.user.findUnique({
                where: { phone_no }
            });
            if (user) {
                const response = await fetch(`${SINCH_BASE_URL}/verifications/number/${encodeURIComponent(phone_no)}`, {
                    method: 'PUT',
                    headers: {
                        'Content-Type': 'application/json',
                        Authorization: 'Basic ' + Buffer.from(`${SINCH_APPLICATION_KEY}:${SINCH_APPLICATION_SECRET}`).toString('base64')
                    },
                    body: JSON.stringify({
                        method: 'sms',
                        sms: { code: otp }
                    })
                });

                const data = await response.json();
                if (response.ok) {
                    if (data.status === 'FAIL') {
                        return res.status(400).json({ message: `OTP ${data.reason}`, status: 200, success: false });
                    }
                    await prisma.user.update({
                        where: { phone_no },
                        data: { otp: null, otpExpiration: null }
                    });
                    return res.status(200).json({
                        message: 'Otp verified successfully',
                        status: 200,
                        success: true,
                    });
                } else {
                    res.status(response.status).json({ message: `${data.message}`, error: data });
                }
            }
            else {
                return res.status(400).json({
                    success: false,
                    status: 400,
                    message: 'User not found'
                });
            }

        }

    } catch (error) {
        console.error(error);
        return res.status(500).json({
            status: 200,
            message: 'Internal Server Error',
            success: false,
            error: error
        })

    }
}

export async function resetPassword(req, res, next) {
    try {
        const secretKey = process.env.SECRET_KEY;
        const { email, password } = req.body;

        console.log(req.body)

        if (email) {
            const schema = Joi.alternatives(Joi.object({
                email: Joi.string().min(5).max(255).email({ tlds: { allow: false } }).lowercase().required(),
                password: Joi.string().min(8).max(15).required()
            }))
            const result = schema.validate(req.body);
            if (result.error) {
                const message = result.error.details.map((i) => i.message).join(",");
                return res.status(400).json({
                    message: result.error.details[0].message,
                    error: message,
                    missingParams: result.error.details[0].message,
                    status: 400,
                    success: false,
                });
            }
            const hashedPassword = await bcrypt.hash(password, 10);
            const user = await prisma.user.update({
                where: {
                    email: email
                },
                data: {
                    password: hashedPassword
                }
            })
            // const token = jwt.sign({ userId: user.id }, secretKey, { expiresIn: '3d' });
            return res.status(200).json({
                status: 200,
                message: 'Password Reset Successfully,You can now login',
                success: true,
                // token,
                user
            })
        }
    } catch (error) {
        console.log(error);
        return res.status(500).json({
            status: 200,
            message: 'Internal Server Error',
            success: false,
            error: error
        })

    }
}

export const getdashboard = async (req, res) => {
    try {
        const adminId = req.user.id;

        const users = await prisma.user.count({
        });

        console.log('users', users)

        const books = await prisma.book.count({
            where: {
                authorId: adminId
            }
        });

        console.log('books', books)
        res.json({
            users, books
        });
    } catch (error) {
        console.log('error', error)
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            status: 500,
            error
        });
    }
};

export async function getAllReader(req, res) {
    try {

        const readers = await prisma.user.findMany({
            orderBy: {
                id: "desc"
            }
        });

        return res.status(200).json({
            success: true,
            message: "Readers retrieved successfully",
            status: 200,
            readers,
        });
    } catch (error) {
        console.error("Error fetching authors:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            status: 500,
            error: error.message,
        });
    }
}

export async function getAllAuthor(req, res) {
    try {

        const author = await prisma.author.findMany({
            orderBy: {
                id: "desc"
            }
        });

        return res.status(200).json({
            success: true,
            message: "Author retrieved successfully",
            status: 200,
            author,
        });
    } catch (error) {
        console.error("Error fetching authors:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            status: 500,
            error: error.message,
        });
    }
}

export async function toggleUserStatusByAdmin(req, res) {
    try {
        const { id } = req.params;

        await prisma.user.findUnique({
            where: { id: req.user.id },
        });

        const user = await prisma.user.findUnique({ where: { id: parseInt(id) } });

        if (!user) {
            return res.status(404).json({ error: 'User not found.' });
        }

        const newStatus = user.status === 1 ? 0 : 1;

        const updatedUser = await prisma.user.update({
            where: { id: parseInt(id) },
            data: { status: newStatus },
        });

        return res.status(200).json({ message: `User  ${newStatus === 1 ? 'Activated' : 'Deactivated'} Successfully`, updatedUser });
        // return res.status(200).json({ message: `User status updated Successfully`, updatedUser });
    } catch (error) {
        console.log('error', error)
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            status: 500,
            error
        });
    }
};

export async function toggleAuthorStatusByAdmin(req, res) {
    try {
        const { id } = req.params;

        await prisma.author.findUnique({
            where: { id: req.user.id },
        });

        const user = await prisma.author.findUnique({ where: { id: parseInt(id) } });

        if (!user) {
            return res.status(404).json({ error: 'User not found.' });
        }

        const newStatus = user.status === 1 ? 0 : 1;

        const updatedUser = await prisma.author.update({
            where: { id: parseInt(id) },
            data: { status: newStatus },
        });

        return res.status(200).json({ message: `User  ${newStatus === 1 ? 'Activated' : 'Deactivated'} Successfully`, updatedUser });
        // return res.status(200).json({ message: `User status updated Successfully`, updatedUser });
    } catch (error) {
        console.log('error', error)
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            status: 500,
            error
        });
    }
};

export async function getAllEbook(req, res) {
    try {

        const ebook = await prisma.book.findMany({
            include: {
                Review: true
            },
            orderBy: {
                id: "desc"
            }
        });

        return res.status(200).json({
            success: true,
            message: "Ebook retrieved successfully",
            status: 200,
            ebook,
        });
    } catch (error) {
        console.error("Error fetching authors:", error);
        return res.status(500).json({
            success: false,
            message: "Internal server error",
            status: 500,
            error: error.message,
        });
    }
};

export async function getAllChats(req, res) {
    try {
        const chats = await prisma.chat.findMany({
            where: {
                participants: {
                    some:
                        { userId: req.user.id },
                }
            },
            include: {
                participants: {
                    include: {
                        User: true
                    },
                },
                lastMessage: true,
            }, orderBy: {
                lastMessage: {
                    updatedAt: 'desc'
                }
            }
        })

        return createSuccessResponse(res, 200, true, MessageEnum.ALL_CHATS, chats)
    } catch (error) {
        console.log(error);
        createErrorResponse(res, 500, MessageEnum.INTERNAL_SERVER_ERROR);
    }
};
