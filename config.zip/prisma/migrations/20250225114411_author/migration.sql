-- AlterTable
ALTER TABLE `author` ADD COLUMN `isFollowed` BOOLEAN NOT NULL DEFAULT false;
