-- AlterTable
ALTER TABLE `admin` ADD COLUMN `isVerified` BOOLEAN NOT NULL DEFAULT false;
