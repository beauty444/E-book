-- DropIndex
DROP INDEX `Author_email_key` ON `author`;
