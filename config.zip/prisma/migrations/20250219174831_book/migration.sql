-- AlterTable
ALTER TABLE `book` MODIFY `userId` INTEGER NULL;
