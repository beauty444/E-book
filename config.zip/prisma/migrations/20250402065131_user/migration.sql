-- AlterTable
ALTER TABLE `user` MODIFY `password` VARCHAR(191) NULL;
