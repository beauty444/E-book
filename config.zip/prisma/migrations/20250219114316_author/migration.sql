-- AlterTable
ALTER TABLE `author` ADD COLUMN `facebook` VARCHAR(191) NULL,
    ADD COLUMN `genres` VARCHAR(191) NULL,
    ADD COLUMN `instagram` VARCHAR(191) NULL;
