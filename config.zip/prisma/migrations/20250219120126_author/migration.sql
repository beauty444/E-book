-- AlterTable
ALTER TABLE `author` ADD COLUMN `coverImage` VARCHAR(191) NULL;
