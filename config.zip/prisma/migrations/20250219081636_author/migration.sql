-- AlterTable
ALTER TABLE `author` MODIFY `dob` DATETIME(3) NULL;
