-- AlterTable
ALTER TABLE `follow` MODIFY `isFollowed` BOOLEAN NOT NULL DEFAULT false;
