-- AlterTable
ALTER TABLE `author` ADD COLUMN `isVerified` BOOLEAN NOT NULL DEFAULT false;
