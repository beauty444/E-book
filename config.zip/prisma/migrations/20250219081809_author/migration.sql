-- AlterTable
ALTER TABLE `admin` ADD COLUMN `act_token` VARCHAR(191) NULL;

-- AlterTable
ALTER TABLE `author` ADD COLUMN `act_token` VARCHAR(191) NULL;
