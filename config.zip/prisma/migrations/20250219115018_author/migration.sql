-- AlterTable
ALTER TABLE `author` MODIFY `fullName` VARCHAR(191) NULL;
