-- AlterTable
ALTER TABLE `author` MODIFY `email` VARCHAR(191) NULL,
    MODIFY `password` VARCHAR(191) NULL;
