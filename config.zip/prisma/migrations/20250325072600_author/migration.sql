-- AlterTable
ALTER TABLE `author` ADD COLUMN `otpExpiration` DATETIME(3) NULL;
