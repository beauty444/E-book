-- AlterTable
ALTER TABLE `chatmessage` MODIFY `chatId` INTEGER NULL;
